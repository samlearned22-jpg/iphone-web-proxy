const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');

const HOST = process.env.JARVIS_HOST || '127.0.0.1';
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8'
};

function send(res, status, body, type = 'application/json; charset=utf-8') {
  res.writeHead(status, {
    'Content-Type': type,
    'X-Content-Type-Options': 'nosniff',
    'Cache-Control': 'no-store',
    'Content-Security-Policy': "default-src 'self' data: blob:; img-src 'self' data: blob:; media-src 'self' blob:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self' http://127.0.0.1:11434"
  });
  res.end(typeof body === 'string' ? body : JSON.stringify(body));
}

function readJson(req, maxBytes = 32 * 1024) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
      if (Buffer.byteLength(data) > maxBytes) {
        reject(new Error('Request is too large.'));
        req.destroy();
      }
    });
    req.on('end', () => {
      try { resolve(JSON.parse(data || '{}')); }
      catch { reject(new Error('Please send valid JSON.')); }
    });
    req.on('error', reject);
  });
}

function builtinReply(message) {
  const q = String(message || '').trim();
  const s = q.toLowerCase();
  if (!q) return 'Tell me what you need.';
  if (/^(help|what can you do|list commands)\??$/.test(s)) {
    return 'I can answer simple local commands and use an optional local Ollama model. Try: time, date, open YouTube, search Google for photography, or ask a question. Notes and memory are stored by the browser interface.';
  }
  if (s === 'time' || s.includes('what time')) {
    return 'The time is ' + new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) + '.';
  }
  if (s === 'date' || s.includes('what date') || s.includes("today's date")) {
    return 'Today is ' + new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) + '.';
  }
  return null;
}

async function askOllama(message) {
  // Ollama is optional; no API key is sent or stored.
  const model = process.env.OLLAMA_MODEL || 'llama3.2';
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 90000);
  try {
    const response = await fetch('http://127.0.0.1:11434/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model,
        stream: false,
        messages: [
          { role: 'system', content: 'You are J.A.R.V.I.S., a helpful, concise assistant. Be honest about your capabilities. Help the user learn rather than simply doing schoolwork without explanation.' },
          { role: 'user', content: message }
        ]
      }),
      signal: controller.signal
    });
    if (!response.ok) throw new Error('Ollama responded with HTTP ' + response.status);
    const data = await response.json();
    return data.message?.content || 'The local model returned an empty response.';
  } finally {
    clearTimeout(timer);
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

  if (req.method === 'GET' && url.pathname === '/api/status') {
    let ollama = false;
    try {
      const r = await fetch('http://127.0.0.1:11434/api/tags', { signal: AbortSignal.timeout(1200) });
      ollama = r.ok;
    } catch {}
    return send(res, 200, { online: true, ollamaAvailable: ollama, model: process.env.OLLAMA_MODEL || 'llama3.2' });
  }

  if (req.method === 'POST' && url.pathname === '/api/assistant') {
    try {
      const data = await readJson(req);
      const message = String(data.message || '').trim();
      if (!message) return send(res, 400, { error: 'Message is empty.' });
      if (message.length > 8000) return send(res, 413, { error: 'Message is too long (maximum 8,000 characters).' });
      const builtIn = builtinReply(message);
      if (builtIn) return send(res, 200, { reply: builtIn, source: 'built-in' });
      try {
        const reply = await askOllama(message);
        return send(res, 200, { reply, source: 'ollama' });
      } catch {
        return send(res, 200, {
          reply: 'The local proxy is working, but no local AI model is available yet. Install Ollama, download a model, and start Ollama to enable open-ended answers. No API key is required. Built-in commands such as help, time, and date still work.',
          source: 'built-in'
        });
      }
    } catch (err) {
      return send(res, 400, { error: err.message || 'Could not process request.' });
    }
  }

  if (req.method !== 'GET' && req.method !== 'HEAD') {
    return send(res, 405, { error: 'Method not allowed.' });
  }

  let pathname = decodeURIComponent(url.pathname);
  if (pathname === '/') pathname = '/index.html';
  const fullPath = path.resolve(ROOT, '.' + pathname);
  if (!fullPath.startsWith(ROOT + path.sep) && fullPath !== path.join(ROOT, 'index.html')) {
    return send(res, 403, { error: 'Forbidden.' });
  }
  fs.stat(fullPath, (err, stat) => {
    if (err || !stat.isFile()) return send(res, 404, { error: 'File not found.' });
    const type = MIME[path.extname(fullPath).toLowerCase()] || 'application/octet-stream';
    res.writeHead(200, {
      'Content-Type': type,
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'no-store'
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(fullPath).pipe(res);
  });
});

server.listen(PORT, HOST, () => {
  console.log('');
  console.log('J.A.R.V.I.S. LOCAL PROXY ONLINE');
  console.log(`Open: http://${HOST}:${PORT}`);
  console.log('Local-only by default. Do not expose this server to the public internet.');
  console.log('Optional AI: install Ollama and download a model (see README.txt).');
  console.log('');
});
