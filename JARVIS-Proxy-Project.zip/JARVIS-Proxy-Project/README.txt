J.A.R.V.I.S. LOCAL PROXY — Samuel & Luca
=========================================

WHAT THIS ZIP CONTAINS
- index.html: your J.A.R.V.I.S. interface, updated to contact the local proxy when it needs an answer.
- server.js: a small local Node.js server and assistant endpoint.
- package.json: no npm packages are required.
- manifest.json, icon.svg, sw.js: installable-web-app support and offline shell.

IMPORTANT
This is a local development proxy, not an anonymous/public internet proxy. It binds to 127.0.0.1 by default so it is not exposed to other devices or the internet.
It works without an API key for built-in commands. For general AI answers, it can optionally use Ollama running on the same PC. The proxy itself does not magically provide a large language model.

WINDOWS SETUP
1. Transfer and extract this ZIP on your Windows PC.
2. Put the extracted files in a folder, for example C:\JARVIS-Proxy.
3. Install Node.js 18 or newer if it is not already installed.
4. Open the folder in File Explorer.
5. Click the address bar, type cmd, and press Enter.
6. In Command Prompt, run:
       node server.js
7. Leave that window open.
8. Open this address in your browser:
       http://127.0.0.1:3000
9. Try: help, time, date, then ask a normal question. Without Ollama, normal questions will tell you how to enable the local model.

OPTIONAL LOCAL AI — NO API KEY
1. Install Ollama from https://ollama.com/download
2. Open Command Prompt and run:
       ollama pull llama3.2
3. Make sure Ollama is running.
4. Keep J.A.R.V.I.S. running at http://127.0.0.1:3000 and ask it a question.
   The first model download can take several gigabytes and depends on your PC.

IPHONE NOTE
The proxy cannot run just by opening this ZIP on an iPhone. The server must run on a computer or server. Once it works on Windows, we can set up a secure way for the iPhone web app to reach it. Do not expose the local proxy directly to the public internet.

TROUBLESHOOTING
- 'node is not recognized': install Node.js, close and reopen Command Prompt, then retry.
- 'address already in use': another app is using port 3000; close the other server or use a different PORT.
- Interface opens but AI says no model: built-in commands are working; install/start Ollama and pull llama3.2.
- The service worker is registered from ./sw.js (the earlier HTML pointed to service-worker.js, which did not match the file name).
